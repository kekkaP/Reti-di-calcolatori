#include <stdio.h>
#include <stdlib.h>
#include "cJSON-master/cJSON.h"
#include "structures.c"
#include <string.h>

/**
 * @brief Legge il contenuto di un file e lo restituisce come una stringa.
 *
 * Questa funzione apre un file in modalit� lettura, legge il suo contenuto e lo restituisce
 * come una stringa allocata dinamicamente. Se il file non pu� essere aperto, viene stampato
 * un messaggio di errore e la funzione restituisce NULL.
 *
 * @param filename Il percorso del file da leggere.
 * @return Un puntatore alla stringa contenente il contenuto del file, o NULL se il file
 *         non pu� essere aperto.
 */
char *read_file(const char *filename){
	// Apri il file in modalit� lettura
    FILE *file = fopen(filename, "r");
    if (!file){
    	 // Se il file non pu� essere aperto, stampa un messaggio di errore e ritorna NULL
        fprintf(stderr, "File %s Mancante", filename);
        return NULL;
    }
     // Vai alla fine del file per determinare la sua lunghezza
    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);
     // Alloca memoria per il buffer che conterr� il contenuto del file
    char *buffer = (char*)malloc(length+1);
    // Leggi il contenuto del file nel buffer
    fread(buffer, 1, length, file);
    // Chiudi il file
    fclose(file);
    // Aggiungi il terminatore nullo alla fine del buffer
    buffer[length] = '\0';
    // Ritorna il buffer contenente il contenuto del file
    return buffer;
}

/**
 * @brief Scrive il contenuto di una stringa in un file.
 *
 * Questa funzione apre un file in modalit� scrittura e scrive il contenuto
 * della stringa specificata nel file. Se il file non pu� essere aperto,
 * viene stampato un messaggio di errore.
 *
 * @param filename Il percorso del file in cui scrivere.
 * @param data La stringa da scrivere nel file.
 */
void write_file(const char *filename, const char *data){
	// Apri il file in modalit� scrittura
    FILE *file = fopen(filename, "w");
    if (!file){
    	// Se il file non pu� essere aperto, stampa un messaggio di errore
        fprintf(stderr, "File %s Mancante", filename);
    }
     // Scrivi la stringa data nel file
    fputs(data, file);
    // Chiudi il file
    fclose(file);
}

/**
 * @brief Registra un nuovo utente nel file "Subscribers.json".
 *
 * Questa funzione legge il contenuto del file "Subscribers.json", aggiunge
 * un nuovo utente con i dettagli forniti e riscrive il file con il nuovo
 * contenuto. L'utente � rappresentato come una struttura JSON.
 *
 * @param user La struttura User contenente i dettagli dell'utente da registrare.
 */
void registerUser(struct User user){
    const char *filename = "Subscribers.json";
     // Leggi il contenuto del file JSON esistente
    char *jsonData = read_file(filename);
     // Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);
     // Crea un nuovo oggetto JSON per l'utente
    cJSON *userObject = cJSON_CreateObject();
    cJSON_AddItemToObject(userObject, "name", cJSON_CreateString(user.name));
    cJSON_AddItemToObject(userObject, "surname", cJSON_CreateString(user.surname));
    cJSON_AddItemToObject(userObject, "residence", cJSON_CreateString(user.residence));
    cJSON_AddItemToObject(userObject, "phoneNumber", cJSON_CreateString(user.phoneNumber));
    
    // Crea un oggetto JSON per l'account dell'utente
    cJSON *account_object = cJSON_CreateObject();
    cJSON *tariffPlanObject = cJSON_CreateObject();

    // Aggiungi i dettagli del piano tariffario all'oggetto tariffPlanObject
    cJSON_AddItemToObject(tariffPlanObject, "name", cJSON_CreateString(user.account.tariffplan.name));
    cJSON_AddItemToObject(tariffPlanObject, "smsCost", cJSON_CreateNumber(user.account.tariffplan.smsCost));
    cJSON_AddItemToObject(tariffPlanObject, "callCostPerMinute", cJSON_CreateNumber(user.account.tariffplan.callCostPerMinute));
    cJSON_AddItemToObject(tariffPlanObject, "dataCostPerKiloByte", cJSON_CreateNumber(user.account.tariffplan.dataCostPerKiloByte));
    cJSON_AddItemToObject(tariffPlanObject, "smsLimit", cJSON_CreateNumber(user.account.tariffplan.smsLimit));
    cJSON_AddItemToObject(tariffPlanObject, "callMinutesLimit", cJSON_CreateNumber(user.account.tariffplan.callMinutesLimit));
    cJSON_AddItemToObject(tariffPlanObject, "dataUsageLimit", cJSON_CreateNumber(user.account.tariffplan.dataUsageLimit));
    cJSON_AddItemToObject(tariffPlanObject, "tariffTotalPrice", cJSON_CreateNumber(user.account.tariffplan.tariffTotalPrice));
    cJSON_AddItemToObject(account_object, "tariffPlan", tariffPlanObject);

    // Aggiungi i dettagli dell'account all'oggetto account_object
    cJSON_AddItemToObject(account_object, "balance", cJSON_CreateNumber(user.account.balance));
    cJSON_AddItemToObject(account_object, "totalCallCost", cJSON_CreateNumber(user.account.totalCallCost));
    cJSON_AddItemToObject(account_object, "totalMessageCost", cJSON_CreateNumber(user.account.totalMessageCost));
    cJSON_AddItemToObject(account_object, "totalDataUsageCost", cJSON_CreateNumber(user.account.totalDataUsageCost));
    cJSON_AddItemToObject(account_object, "totalMessages", cJSON_CreateNumber(user.account.totalMessages));
    cJSON_AddItemToObject(account_object, "totalCallsMinutes", cJSON_CreateNumber(user.account.totalCallMinutes));
    cJSON_AddItemToObject(account_object, "totalDataUsageKBS", cJSON_CreateNumber(user.account.totalDataUsageKBS));
    cJSON_AddItemToObject(userObject, "account", account_object);

// Aggiungi il nuovo utente all'array JSON root
    cJSON_AddItemToArray(root, userObject);
// Stampa il nuovo contenuto JSON come stringa
    char *newJsonData = cJSON_Print(root);
// Scrivi il nuovo contenuto JSON nel file
    write_file("Subscribers.json", newJsonData);
 // Pulisci la memoria allocata
    cJSON_Delete(root);
    free(newJsonData);
}

/**
 * @brief Crea un nuovo piano tariffario e lo aggiunge al file "TariffPlans.json".
 *
 * Questa funzione legge il contenuto del file "TariffPlans.json", aggiunge un nuovo
 * piano tariffario con i dettagli forniti e riscrive il file con il nuovo contenuto.
 * Il piano tariffario � rappresentato come una struttura JSON.
 *
 * @param tariff La struttura TariffPlan contenente i dettagli del piano tariffario da creare.
 */
void createTariff(struct TariffPlan tariff){
    const char *filename = "TariffPlans.json";
    // Leggi il contenuto del file JSON esistente
    char *jsonData = read_file(filename);
// Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);
    // Crea un nuovo oggetto JSON per il piano tariffario
    cJSON *tariffObject = cJSON_CreateObject();
    cJSON_AddItemToObject(tariffObject, "name", cJSON_CreateString(tariff.name));
    cJSON_AddItemToObject(tariffObject, "smsCost", cJSON_CreateNumber(tariff.smsCost));
    cJSON_AddItemToObject(tariffObject, "callCostPerMinute", cJSON_CreateNumber(tariff.callCostPerMinute));
    cJSON_AddItemToObject(tariffObject, "dataCostPerKiloByte", cJSON_CreateNumber(tariff.dataCostPerKiloByte));
    cJSON_AddItemToObject(tariffObject, "smsLimit", cJSON_CreateNumber(tariff.smsLimit));
    cJSON_AddItemToObject(tariffObject, "callMinutesLimit", cJSON_CreateNumber(tariff.callMinutesLimit));
    cJSON_AddItemToObject(tariffObject, "dataUsageLimit", cJSON_CreateNumber(tariff.dataUsageLimit));
    cJSON_AddItemToObject(tariffObject, "tariffTotalPrice", cJSON_CreateNumber(tariff.tariffTotalPrice));
    // Aggiungi il nuovo piano tariffario all'array JSON root
	cJSON_AddItemToArray(root, tariffObject);
	// Stampa il nuovo contenuto JSON come stringa
    char *newJsonData = cJSON_Print(root);
    // Scrivi il nuovo contenuto JSON nel file
    write_file("TariffPlans.json", newJsonData);
    // Pulisci la memoria allocata
    cJSON_Delete(root);
    free(newJsonData);
}

/**
 * @brief Legge le offerte tariffarie dal file "TariffPlans.json" e le restituisce come un array di stringhe.
 *
 * Questa funzione legge il contenuto del file "TariffPlans.json", analizza il contenuto JSON per estrarre
 * le informazioni delle offerte tariffarie, e le formatta in un array di stringhe. Ogni stringa contiene
 * i dettagli di un'offerta tariffaria separati da tabulazioni.
 *
 * @return Un array di stringhe contenente le offerte tariffarie. Ogni stringa � allocata dinamicamente e
 *         deve essere liberata dal chiamante.
 */

char **read_offers() {
    const char *filename = "TariffPlans.json";
    // Leggi il contenuto del file JSON
    char *jsonData = read_file(filename);
    // Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    // Ottieni la dimensione dell'array JSON
    int arraySize = cJSON_GetArraySize(root);
    // Alloca memoria per l'array di stringhe
    char **tariffList = malloc(arraySize * sizeof(char *));

    cJSON *element;
    int ctr = 0;
    // Itera attraverso ogni elemento dell'array JSON
    cJSON_ArrayForEach(element, root) {
    	 // Estrai i dettagli del piano tariffario
        char *nome = cJSON_GetObjectItem(element, "name")->valuestring;
        double smsCost = cJSON_GetObjectItem(element, "smsCost")->valuedouble;
        double callCostPerMinute = cJSON_GetObjectItem(element, "callCostPerMinute")->valuedouble;
        double dataCostPerKiloByte = cJSON_GetObjectItem(element, "dataCostPerKiloByte")->valuedouble;
        double smsLimit = cJSON_GetObjectItem(element, "smsLimit")->valuedouble;
        double callMinutesLimit = cJSON_GetObjectItem(element, "callMinutesLimit")->valuedouble;
        double dataUsageLimit = cJSON_GetObjectItem(element, "dataUsageLimit")->valuedouble;
        double tariffTotalPrice = cJSON_GetObjectItem(element, "tariffTotalPrice")->valuedouble;
// Alloca memoria per la stringa di output
        char *output = malloc(1000 * sizeof(char));
 // Formatta i dettagli del piano tariffario nella stringa di output
        snprintf(output, 1000, "%s\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f",
                 nome, smsCost, callCostPerMinute, dataCostPerKiloByte,
                 smsLimit, callMinutesLimit, dataUsageLimit, tariffTotalPrice);
// Aggiungi la stringa di output all'array
        tariffList[ctr] = output;
        ctr++;
    }
 // Libera la memoria allocata per l'oggetto JSON
    cJSON_Delete(root);
// Ritorna l'array di stringhe contenente le offerte tariffarie
    return tariffList;
}

/**
 * @brief Legge le offerte tariffarie dal file "TariffPlans.json" e le restituisce come una singola stringa.
 *
 * Questa funzione legge il contenuto del file "TariffPlans.json", analizza il contenuto JSON per estrarre
 * le informazioni delle offerte tariffarie, e le formatta in una singola stringa. Ogni offerta � separata
 * da una nuova linea, e i dettagli di ogni offerta sono separati da tabulazioni.
 *
 * @return Una stringa contenente tutte le offerte tariffarie. La stringa � allocata dinamicamente e deve
 *         essere liberata dal chiamante.
 */
char *read_offers_string() {
    const char *filename = "TariffPlans.json";
    // Leggi il contenuto del file JSON
    char *jsonData = read_file(filename);
    // Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
// Ottieni la dimensione dell'array JSON
    int arraySize = cJSON_GetArraySize(root);
    // Alloca memoria per la stringa che conterr� tutte le tariffe
    char *tariffList = malloc(arraySize * 1000 * sizeof(char)); // Supponendo che ogni tariffa non superi i 1000 caratteri
// Controlla se la memoria � stata allocata correttamente
    if (tariffList == NULL) {
        fprintf(stderr, "Errore di allocazione della memoria.\n");
        exit(EXIT_FAILURE);
    }

    int offset = 0;
    cJSON *element;
    // Itera attraverso ogni elemento dell'array JSON
    cJSON_ArrayForEach(element, root) {
    	 // Estrai i dettagli del piano tariffario
        char *nome = cJSON_GetObjectItem(element, "name")->valuestring;
        double smsCost = cJSON_GetObjectItem(element, "smsCost")->valuedouble;
        double callCostPerMinute = cJSON_GetObjectItem(element, "callCostPerMinute")->valuedouble;
        double dataCostPerKiloByte = cJSON_GetObjectItem(element, "dataCostPerKiloByte")->valuedouble;
        double smsLimit = cJSON_GetObjectItem(element, "smsLimit")->valuedouble;
        double callMinutesLimit = cJSON_GetObjectItem(element, "callMinutesLimit")->valuedouble;
        double dataUsageLimit = cJSON_GetObjectItem(element, "dataUsageLimit")->valuedouble;
        double tariffTotalPrice = cJSON_GetObjectItem(element, "tariffTotalPrice")->valuedouble;
 // Formatta i dettagli del piano tariffario nella stringa di output
        int written = snprintf(tariffList + offset, 1000, "%s\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\n",
                 nome, smsCost, callCostPerMinute, dataCostPerKiloByte,
                 smsLimit, callMinutesLimit, dataUsageLimit, tariffTotalPrice);
         // Controlla se ci sono errori durante la formattazione della stringa
        if (written < 0) {
            fprintf(stderr, "Errore durante la formattazione della stringa.\n");
            exit(EXIT_FAILURE);
        }
        // Aggiorna l'offset per la prossima iterazione
        offset += written;
    }
 // Libera la memoria allocata per l'oggetto JSON
    cJSON_Delete(root);
// Ritorna la stringa contenente tutte le offerte tariffarie
    return tariffList;
}

/**
 * @brief Cambia il piano tariffario di un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito,
 * quindi legge il file "TariffPlans.json" per trovare il nuovo piano tariffario con il nome fornito. Una volta
 * trovato, aggiorna il piano tariffario dell'utente e riscrive il file "Subscribers.json" con le modifiche.
 *
 * @param phoneNumber Il numero di telefono dell'utente il cui piano tariffario deve essere cambiato.
 * @param newTariffName Il nome del nuovo piano tariffario da assegnare all'utente.
 */
void changeTariff(const char *phoneNumber, const char *newTariffName) {
    const char *filename_subscribers = "Subscribers.json";
     // Leggi il contenuto del file Subscribers.json
    char *jsondata_subscribers = read_file(filename_subscribers);
// Analizza il contenuto JSON dei subscribers
    cJSON *root_subscribers = cJSON_Parse(jsondata_subscribers);
    free(jsondata_subscribers);

    cJSON *element_subscriber;
     // Itera attraverso ogni subscriber nel file JSON
    cJSON_ArrayForEach(element_subscriber, root_subscribers) {
        char *value = cJSON_GetObjectItem(element_subscriber, "phoneNumber")->valuestring;
        // Se il numero di telefono corrisponde, cambia il piano tariffario
		if (strcmp(value, phoneNumber) == 0) {
            cJSON *accountObject = cJSON_GetObjectItem(element_subscriber, "account");
            cJSON *tariffPlanObject = cJSON_GetObjectItem(accountObject, "tariffPlan");

            const char *filename_tariffplans = "TariffPlans.json";
             // Leggi il contenuto del file TariffPlans.json
            char *jsondata_tariffplans = read_file(filename_tariffplans);
             // Analizza il contenuto JSON dei piani tariffari
            cJSON *root_tariffplans = cJSON_Parse(jsondata_tariffplans);
            free(jsondata_tariffplans);

            cJSON *element_tariffplan;
             // Itera attraverso ogni piano tariffario nel file JSON
            cJSON_ArrayForEach(element_tariffplan, root_tariffplans) {
                char *nome = cJSON_GetObjectItem(element_tariffplan, "name")->valuestring;
                 // Se il nome del piano tariffario corrisponde, aggiorna il piano tariffario dell'utente
				if (strcmp(nome, newTariffName) == 0) {
					 // Rimuovi i vecchi dettagli del piano tariffario
                    cJSON_DeleteItemFromObject(tariffPlanObject, "name");
                    cJSON_DeleteItemFromObject(tariffPlanObject, "smsCost");
                    cJSON_DeleteItemFromObject(tariffPlanObject, "callCostPerMinute");
                    cJSON_DeleteItemFromObject(tariffPlanObject, "dataCostPerKiloByte");
                    cJSON_DeleteItemFromObject(tariffPlanObject, "smsLimit");
                    cJSON_DeleteItemFromObject(tariffPlanObject, "callMinutesLimit");
                    cJSON_DeleteItemFromObject(tariffPlanObject, "dataUsageLimit");
                    cJSON_DeleteItemFromObject(tariffPlanObject, "tariffTotalPrice");

                     // Aggiungi i nuovi dettagli del piano tariffario
					cJSON_AddItemToObject(tariffPlanObject, "name", cJSON_CreateString(cJSON_GetObjectItem(element_tariffplan, "name")->valuestring));
                    cJSON_AddItemToObject(tariffPlanObject, "smsCost", cJSON_CreateNumber(cJSON_GetObjectItem(element_tariffplan, "smsCost")->valuedouble));
                    cJSON_AddItemToObject(tariffPlanObject, "callCostPerMinute", cJSON_CreateNumber(cJSON_GetObjectItem(element_tariffplan, "callCostPerMinute")->valuedouble));
                    cJSON_AddItemToObject(tariffPlanObject, "dataCostPerKiloByte", cJSON_CreateNumber(cJSON_GetObjectItem(element_tariffplan, "dataCostPerKiloByte")->valuedouble));
                    cJSON_AddItemToObject(tariffPlanObject, "smsLimit", cJSON_CreateNumber(cJSON_GetObjectItem(element_tariffplan, "smsLimit")->valuedouble));
                    cJSON_AddItemToObject(tariffPlanObject, "callMinutesLimit", cJSON_CreateNumber(cJSON_GetObjectItem(element_tariffplan, "callMinutesLimit")->valuedouble));
                    cJSON_AddItemToObject(tariffPlanObject, "dataUsageLimit", cJSON_CreateNumber(cJSON_GetObjectItem(element_tariffplan, "dataUsageLimit")->valuedouble));
                    cJSON_AddItemToObject(tariffPlanObject, "tariffTotalPrice", cJSON_CreateNumber(cJSON_GetObjectItem(element_tariffplan, "tariffTotalPrice")->valuedouble));

                    break;
                }
            }

            cJSON_Delete(root_tariffplans);
        }
    }

    // Scrivi le modifiche nel file Subscribers.json
    char *modified_json_string = cJSON_Print(root_subscribers);
    FILE *output_file = fopen(filename_subscribers, "w");
    if (output_file == NULL) {
        perror("Impossibile aprire il file di output");
        cJSON_Delete(root_subscribers);
        free(modified_json_string);
        exit(EXIT_FAILURE);
    }

    fputs(modified_json_string, output_file);
    fclose(output_file);

    cJSON_Delete(root_subscribers);
    free(modified_json_string);
}

/**
 * @brief Ottiene il saldo del conto di un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, restituisce il saldo del conto dell'utente.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera ottenere il saldo.
 * @return Il saldo del conto dell'utente. Se l'utente non viene trovato, restituisce 0.
 */
float getBalance(const char *number){
    const char *filename = "Subscribers.json";
    // Leggi il contenuto del file Subscribers.json
    char *jsonData = read_file(filename);
// Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
    // Itera attraverso ogni subscriber nel file JSON
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
         // Se il numero di telefono corrisponde, restituisci il saldo del conto
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");
            double ret = cJSON_GetObjectItem(accountObject, "balance")->valuedouble;
            cJSON_Delete(root);
            return ret;
        }
    }
}

/**
 * @brief Ottiene il costo per minuto delle chiamate del piano tariffario di un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, restituisce il costo per minuto delle chiamate del piano tariffario dell'utente.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera ottenere il costo per minuto delle chiamate.
 * @return Il costo per minuto delle chiamate del piano tariffario dell'utente. Se l'utente non viene trovato, restituisce 0.
 */
float getCallCost(const char *number){
    const char *filename = "Subscribers.json";
    // Leggi il contenuto del file Subscribers.json
    char *jsonData = read_file(filename);
    // Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
     // Itera attraverso ogni subscriber nel file JSON
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
        // Se il numero di telefono corrisponde, restituisci il costo per minuto delle chiamate
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");
            cJSON *tariffObject = cJSON_GetObjectItem(accountObject, "tariffPlan");
            float ret = cJSON_GetObjectItem(tariffObject, "callCostPerMinute")->valuedouble;
            cJSON_Delete(root);
            return ret;
        }
    }
}

/**
 * @brief Ottiene il costo dei messaggi SMS del piano tariffario di un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, restituisce il costo dei messaggi SMS del piano tariffario dell'utente.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera ottenere il costo dei messaggi SMS.
 * @return Il costo dei messaggi SMS del piano tariffario dell'utente. Se l'utente non viene trovato, restituisce 0.
 */
float getMessCost(const char *number){
    const char *filename = "Subscribers.json";
    // Leggi il contenuto del file Subscribers.json
    char *jsonData = read_file(filename);
     // Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
    // Itera attraverso ogni subscriber nel file JSON
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
        // Se il numero di telefono corrisponde, restituisci il costo dei messaggi SMS
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");
            cJSON *tariffObject = cJSON_GetObjectItem(accountObject, "tariffPlan");
            float ret = cJSON_GetObjectItem(tariffObject, "smsCost")->valuedouble;
            cJSON_Delete(root);
            return ret;
        }
    }
}

/**
 * @brief Ottiene il costo per kilobyte di dati del piano tariffario di un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, restituisce il costo per kilobyte di dati del piano tariffario dell'utente.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera ottenere il costo per kilobyte di dati.
 * @return Il costo per kilobyte di dati del piano tariffario dell'utente. Se l'utente non viene trovato, restituisce 0.
 */
float getKBCost(const char *number){
    const char *filename = "Subscribers.json";
    // Leggi il contenuto del file Subscribers.json
    char *jsonData = read_file(filename);
    // Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
    // Itera attraverso ogni subscriber nel file JSON
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
        // Se il numero di telefono corrisponde, restituisci il costo per kilobyte di dati
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");
            cJSON *tariffObject = cJSON_GetObjectItem(accountObject, "tariffPlan");
            float ret = cJSON_GetObjectItem(tariffObject, "dataCostPerKiloByte")->valuedouble;
            cJSON_Delete(root);
            return ret;
        }
    }
    
}

/**
 * @brief Aumenta il numero totale di minuti di chiamata per un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, aumenta il numero totale di minuti di chiamata dell'utente e aggiorna il file JSON.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera aumentare i minuti di chiamata.
 * @param amount La quantit� da aggiungere ai minuti di chiamata esistenti.
 */
float increaseMinUsage(const char *number, float amount){
    const char *filename = "Subscribers.json";
     // Leggi il contenuto del file Subscribers.json
    char *jsonData = read_file(filename);
 // Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
    // Itera attraverso ogni subscriber nel file JSON
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
         // Se il numero di telefono corrisponde, aggiorna i minuti di chiamata dell'utente
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");

            double mins = cJSON_GetObjectItem(accountObject, "totalCallsMinutes")->valuedouble;
            mins += amount;
         // Elimina il campo totalCallsMinutes esistente e aggiungi il nuovo valore aggiornato
            cJSON_DeleteItemFromObject(accountObject, "totalCallsMinutes");
            cJSON_AddItemToObject(accountObject, "totalCallsMinutes", cJSON_CreateNumber(mins));

            break;
        }
    }
}

/**
 * @brief Aumenta il numero totale di messaggi SMS per un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, aumenta il numero totale di messaggi SMS dell'utente e aggiorna il file JSON.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera aumentare i messaggi SMS.
 * @param amount La quantit� da aggiungere ai messaggi SMS esistenti.
 */
float increaseSMSUsage(const char *number, float amount){
    const char *filename = "Subscribers.json";
    // Leggi il contenuto del file Subscribers.json
    char *jsonData = read_file(filename);
// Analizza il contenuto JSON
    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
     // Itera attraverso ogni subscriber nel file JSON
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
        // Se il numero di telefono corrisponde, aggiorna i messaggi SMS dell'utente
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");

            double mins = cJSON_GetObjectItem(accountObject, "totalMessages")->valuedouble;
            mins += amount;
 // Elimina il campo totalMessages esistente e aggiungi il nuovo valore aggiornato
            cJSON_DeleteItemFromObject(accountObject, "totalMessages");
            cJSON_AddItemToObject(accountObject, "totalMessages", cJSON_CreateNumber(mins));

            break;
        }
    }
}

/**
 * @brief Aumenta il numero totale di kilobyte di dati utilizzati per un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, aumenta il numero totale di kilobyte di dati utilizzati dell'utente e aggiorna il file JSON.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera aumentare i kilobyte di dati utilizzati.
 * @param amount La quantit� da aggiungere ai kilobyte di dati utilizzati esistenti.
 */
float increaseKBUsage(const char *number, float amount){
    const char *filename = "Subscribers.json";
    char *jsonData = read_file(filename);

    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
         // Se il numero di telefono corrisponde, aggiorna i kilobyte di dati utilizzati dell'utente
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");

            double mins = cJSON_GetObjectItem(accountObject, "totalDataUsageKBS")->valuedouble;
            mins += amount;
// Elimina il campo totalDataUsageKBS esistente e aggiungi il nuovo valore aggiornato
            cJSON_DeleteItemFromObject(accountObject, "totalDataUsageKBS");
            cJSON_AddItemToObject(accountObject, "totalDataUsageKBS", cJSON_CreateNumber(mins));

            break;
        }
    }
} 

/**
 * @brief Resetta i conteggi di utilizzo (minuti di chiamata, messaggi SMS, dati utilizzati) per un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, resetta i conteggi di minuti di chiamata, messaggi SMS e dati utilizzati dell'utente a zero nel file JSON.
 *
 * @param number Il numero di telefono dell'utente di cui si desidera resettare i conteggi di utilizzo.
 */
void resetUsages(const char *number){
    const char *filename = "Subscribers.json";
    char *jsonData = read_file(filename);

    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);

    cJSON *elementSubscriber;
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
         // Se il numero di telefono corrisponde, resetta i conteggi di utilizzo dell'utente
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");
         // Elimina i campi esistenti e aggiungi i nuovi valori a zero
            cJSON_DeleteItemFromObject(accountObject, "totalCallsMinutes");
            cJSON_DeleteItemFromObject(accountObject, "totalMessages");
            cJSON_DeleteItemFromObject(accountObject, "totalDataUsageKBS");

            cJSON_AddItemToObject(accountObject, "totalCallsMinutes", cJSON_CreateNumber(0));
            cJSON_AddItemToObject(accountObject, "totalMessages", cJSON_CreateNumber(0));
            cJSON_AddItemToObject(accountObject, "totalDataUsageKBS", cJSON_CreateNumber(0));

            break;
        }
    }
}

/**
 * @brief Aggiunge una certa quantit� di denaro al saldo dell'account di un utente specifico.
 *
 * Questa funzione legge il file "Subscribers.json" per trovare l'utente con il numero di telefono fornito.
 * Una volta trovato, aggiunge la quantit� specificata al saldo dell'account dell'utente e aggiorna il file JSON con il nuovo saldo.
 *
 * @param number Il numero di telefono dell'utente a cui aggiungere il denaro.
 * @param amount La quantit� di denaro da aggiungere al saldo dell'utente.
 */
void addMoney(const char *number, float amount){
    const char *filename = "Subscribers.json";
    char *jsonData = read_file(filename);

    cJSON *root = cJSON_Parse(jsonData);
    free(jsonData);
    
    cJSON *elementSubscriber;
    cJSON_ArrayForEach(elementSubscriber, root){
        char *value = cJSON_GetObjectItem(elementSubscriber, "phoneNumber")->valuestring;
        // Se il numero di telefono corrisponde, aggiorna il saldo dell'account dell'utente
		if (strcmp(value, number) == 0){
            cJSON *accountObject = cJSON_GetObjectItem(elementSubscriber, "account");

            double balance = cJSON_GetObjectItem(accountObject, "balance")->valuedouble;
            balance += amount;
// Elimina il campo balance esistente e aggiungi il nuovo saldo aggiornato
            cJSON_DeleteItemFromObject(accountObject, "balance");
            cJSON_AddItemToObject(accountObject, "balance", cJSON_CreateNumber(balance));

            break;
        }
    }
// Converte l'intero JSON modificato in una stringa formattata
    char *modified_json_string = cJSON_Print(root);
    // Apre il file di output per scrivere le modifiche
    FILE *output_file = fopen(filename, "w");
    if (output_file == NULL) {
        perror("Impossibile aprire il file di output");
        cJSON_Delete(root);
        free(modified_json_string);
        exit(EXIT_FAILURE);
    }
// Scrive la stringa JSON nel file di output e chiude il file
    fputs(modified_json_string, output_file);
    fclose(output_file);

    cJSON_Delete(root);
    free(modified_json_string);

}
