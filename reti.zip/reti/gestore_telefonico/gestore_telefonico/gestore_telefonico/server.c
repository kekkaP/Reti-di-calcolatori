#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <semaphore.h>
#include "json.c"

sem_t semaphore;

void error(const char *msg){
    perror(msg);
    exit(1);
}

void rimuovi_newline(char *stringa) {
    int lunghezza = strlen(stringa);
    for (int i = 0; i < lunghezza; i++) {
        if (stringa[i] == '\n') {
            // Spostiamo tutti i caratteri dopo il carattere di nuova riga
            // indietro di una posizione per sovrascrivere il carattere di nuova riga
            for (int j = i; j < lunghezza; j++) {
                stringa[j] = stringa[j + 1];
            }
            // Decrementiamo la lunghezza per considerare la rimozione del carattere di nuova riga
            lunghezza--;
            // Decrementiamo i per compensare la rimozione del carattere di nuova riga
            i--;
        }
    }
}

void *handle_connection(void *socket_desc) {
    int newsockfd = *((int*)socket_desc);
    char buffer[2000];
    int n;

    struct sockaddr_in cli_addr;
    socklen_t cli_len = sizeof(cli_addr);
    char ipString[2000];
    if (getpeername(newsockfd, (struct sockaddr*)&cli_addr, &cli_len) == 0) {
        printf("Client connected from IP: %s\n", inet_ntop(AF_INET, &(cli_addr.sin_addr), ipString, sizeof(ipString)));
    }//Comunicazione dell'avvenuta connessione

    int logged = 0;
    int amministratore = 0;
    int callReceiver = 0;
    while (1){
        
        bzero(buffer, 2000);
        
        if (logged == 0){//Inserisci numero di telefono
            strcpy(buffer, "Inserisci il tuo numero di telefono o digita \"amministratore\" per loggarti come tale, o \"callreceiver\"");
        }else if (amministratore == 1){//Funzioni amministratore
            strcpy(buffer, "1) Aggiungi utente\n2) Aggiungi Tariffa\n3) Mostra Dati utilizzo utenti\n0) Disconnessione e uscita");
        }else if (callReceiver == 1){
            strcpy(buffer, "Inserisci la porta di ascolto:");
            callReceiver = 2;
        }else{
            strcpy(buffer, "1) Effettua Chiamata\n2) Invia SMS\n3) Trasferimento Dati\n4) Cambia Tariffa\n5) Effettua Ricarica\n6) Controlla Messaggi\n7) Inserisci porta ricevitore\n");
        }
        

        n = write(newsockfd, buffer, strlen(buffer));

        if (n < 0){
            error("Error on Writing.\n\n");
        }
        bzero(buffer, 2000);
        //Determinazione della stringa da inviare al client

        n = read(newsockfd, buffer, 2000);
        if (n < 0){
            error("Error on reading.\n\n");
        }
        //Lettura della risposta del client

        int i = strncmp("0", buffer, 1);
        if (i == 0){//Uscita
            printf("Client %s disconnesso.\n", ipString);
            n = write(newsockfd, buffer, strlen(buffer));
            if (n < 0){
                error("Error on Writing.\n\n");
            }
            bzero(buffer, 2000);
            sem_wait(&semaphore);
            eliminaClientERiordina(cli_addr.sin_addr);
            sem_post(&semaphore);
            break;
        }
        if (logged == 0){//NON LOGGATO
            
            i = strncmp("amministratore", buffer, 14);
            if (i == 0){//AUTENTICAZIONE COME AMMINISTRATORE
                printf("%s collegato come amministratore\n", ipString);
                logged = 1;
                amministratore = 1;
            }else{//AUTENTICAZIONE CON NUMERO O COME CALL RECEIVER
                const char *filename = "Subscribers.json";
                char *jsonData = read_file(filename);

                cJSON *root = cJSON_Parse(jsonData);
                free(jsonData);

                cJSON *element;
                int valid = 0;

                cJSON_ArrayForEach(element, root){
                    char *value = cJSON_GetObjectItem(element, "phoneNumber")->valuestring;
                    rimuovi_newline(buffer);
                    int i = strcmp(value, buffer);
                    if (i == 0){
                        //AUTENTICATO CON NUMERO CON SUCCESSO
                        valid = 1;
                        printf("Indirizzo IP %s autenticato con numero %s.\n", ipString, value);
                        logged = 1;
                        struct Contatto c;
                        c.indirizzoIP = cli_addr;
                        strcpy(c.numeroTelefono, value);
                        c.occupato = 0;
                        c.port = 0;

                        sem_wait(&semaphore);
                        aggiungiClient(c);
                        //Aggiunta del client alla lista di client loggati
                        sem_post(&semaphore);
                        
                        break;
                    }
                }
                if (!valid){
                    int i = strncmp("callreceiver", buffer, strlen("callreceiver"));
                    if (i == 0){
                        strcpy(buffer, "Autentificato come callReceiver\n");
                        logged = 1;
                        callReceiver = 1;
                    }else{
                        strcpy(buffer, "Numero di telefono non valido\n.");
                    }
                    
                    n = write(newsockfd, buffer, strlen(buffer));

                    if (n < 0){
                        error("Error on Writing.\n\n");
                    }
                    bzero(buffer, 2000);

                }
                //Controllo se il numero inserito esiste
            }
            bzero(buffer, 2000);
        }else{//LOGGATO UTENTE
            if (amministratore == 0){
                i = strncmp("1", buffer, 1);
                if (i == 0){//Chiamata
                    strcpy(buffer, "Inserisci numero destinatario:\n");
                    n = write(newsockfd, buffer, strlen(buffer));
                    if (n < 0){
                        error("Error on writing\n");
                    }
                    bzero(buffer, 2000);

                    n = read(newsockfd, buffer, 2000);
                    if (n < 0){
                        error("Error on reading");
                    }
                    char *newline_pos = strchr(buffer, '\n');
    
                    // Se il carattere '\n' è presente, lo sostituisci con '\0'
                    if (newline_pos != NULL) {
                        *newline_pos = '\0';
                    }
                    if (numberExists(buffer)){
                        struct in_addr ip = getIpDaTelefono(buffer);
                        char ipString[INET_ADDRSTRLEN];
                        inet_ntop(AF_INET, &ip, ipString, INET_ADDRSTRLEN);
                        int port = getPortaDaTelefono(buffer);
                        bzero(buffer, 2000);
                        if (port == 0){
                            strcpy(buffer, "Numero non raggiungibile\n");
                        }else{
                            char string[2000];
                            sprintf(string, "contact %s %d", ipString, port);
                            strcpy(buffer, string);
                        }

                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on writing\n");
                        }
                        
                    }else{
                        strcpy(buffer, "Numero Inesistente\n");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on writing\n");
                        }
                    }
                    
                    bzero(buffer, 2000);
                    //Gestione della comunicazione per effettuare una chiamata
                }
                i = strncmp("2", buffer, 1);
                if (i == 0){//Sms
                    if (getBalance(getTelefonoDaIP(cli_addr.sin_addr)) <= 0){
                        strcpy(buffer, "Credito Insufficiente!:\n.");
                        n = write(newsockfd, buffer, strlen(buffer));

                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                    bzero(buffer, 2000);
                    }else{
                        strcpy(buffer, "Inserire il numero di telefono del destinatario:\n.");
                        n = write(newsockfd, buffer, strlen(buffer));

                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        char dest[2000];
                        strcpy(dest, buffer);
                        rimuovi_newline(dest);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire il messaggio:\n.");
                        n = write(newsockfd, buffer, strlen(buffer));

                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        char mess[2000];
                        strcpy(mess, buffer);
                        bzero(buffer, 2000);
                        strcpy(buffer, addMessage(dest, mess));
                        n = write(newsockfd, buffer, strlen(buffer));

                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);
                        float cost = getMessCost(getTelefonoDaIP(cli_addr.sin_addr));
                        addMoney(getTelefonoDaIP(cli_addr.sin_addr), -1*cost);
                        increaseSMSUsage(getTelefonoDaIP(cli_addr.sin_addr), 1);
                    }
                    //Gestione della comunicazione per inviare un SMS
                }
                i = strncmp("3", buffer, 1);
                if (i == 0){//Trasferimento
                    if (getBalance(getTelefonoDaIP(cli_addr.sin_addr)) <= 0){
                        strcpy(buffer, "Credito Insufficiente: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on write\n");
                        }
                        bzero(buffer, 2000);
                    }else{
                        strcpy(buffer, "Inserisci cosa vuoi cercare: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on write\n");
                        }
                        bzero(buffer, 2000);
    
                        char search[2000];
                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading\n");
                        }
                        strcpy(search, buffer);
                        bzero(buffer, 2000);
                        float kb = (float)strlen(search) / 1024;
                        float cost = getKBCost(getTelefonoDaIP(cli_addr.sin_addr));
                        addMoney(getTelefonoDaIP(cli_addr.sin_addr), -1*cost*kb);
                        increaseKBUsage(getTelefonoDaIP(cli_addr.sin_addr), kb);
                    }
                    //Gestione della comunicazione per effettuare un trasferimento
                }
                i = strncmp("4", buffer, 1);
                if (i == 0){//Cambia tariffa
                    char* offersString = read_offers_string();
                    strcpy(buffer, offersString);
                    n = write(newsockfd, buffer, strlen(buffer));
                    if (n < 0){
                        error("Error on Writing.\n\n");
                    }
                    bzero(buffer, 2000);

                    n = read(newsockfd, buffer, 2000);
                    if (n < 0){
                        error("Error on reading.\n\n");
                    }
                    
                    int selection = atoi(buffer);
                    char ** offer = read_offers();
                    
                    changeTariff(getTelefonoDaIP(cli_addr.sin_addr), strtok(offer[selection], "\t"));
                    resetUsages(getTelefonoDaIP(cli_addr.sin_addr));
                    //Gestione della comunicazione per cambiare tariffa
                }
                i = strncmp("5", buffer, 1);
                if (i == 0){//Ricarica
                    bzero(buffer, 2000);
                    strcpy(buffer, "Inserisci l'importo:");
                    n = write(newsockfd, buffer, strlen(buffer));
                    if (n < 0){
                        error("Error on writing\n");
                    }
                    bzero(buffer, 2000);

                    n = read(newsockfd, buffer, 2000);
                    if (n < 0){
                        error("Error on reading\n");
                    }
                    float import = atof(buffer);
                    bzero(buffer, 2000);
                    addMoney(getTelefonoDaIP(cli_addr.sin_addr), import);
                    //Gestione della comunicazione per effettuare una ricarica
                }
                i = strncmp("6", buffer, 1);
                if (i == 0){//Richiesta Messaggi
                    strcpy(buffer, getMessages(getTelefonoDaIP(cli_addr.sin_addr)));
                    n = write(newsockfd, buffer, strlen(buffer));
                    if (n < 0){
                        error("Error on Writing.\n\n");
                    }
                    bzero(buffer, 2000);
                    //Invio istruzione per richiedere nuovi messaggi
                }
                i = strncmp("7", buffer, 1);
                if (i == 0){//Aggiunta porta
                    strcpy(buffer, "Inserisci la porta di ascolto:\n");
                    n = write(newsockfd, buffer, strlen(buffer));
                    if (n < 0){
                        error("Error on Writing\n\n");
                    }
                    bzero(buffer, 2000);

                    n = read(newsockfd, buffer, 2000);
                    if (n < 0){
                        error("Error on reading.\n\n");
                    }

                    int port = atoi(buffer);
                    addPort(cli_addr.sin_addr, port);
                    //Aggiunta porta di ascolto del callReceiver
                }
            }else{//LOGGATO AMMINISTRATORE
                
                i = strncmp("1", buffer, 1);
                if (i == 0){//Aggiungi utente
                        struct User u;
                        strcpy(buffer, "Inserire Nome: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        rimuovi_newline(buffer);
                        strcpy(u.name, buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Cognome: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        rimuovi_newline(buffer);
                        strcpy(u.surname, buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Residenza: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        rimuovi_newline(buffer);
                        strcpy(u.residence, buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Numero di Cellulare: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        rimuovi_newline(buffer);
                        strcpy(u.phoneNumber, buffer);
                        bzero(buffer, 2000);

                        char* offersString = read_offers_string();
                        strcpy(buffer, offersString);
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }

                        int selection = atoi(buffer);

                        u.account.balance = 0;
                        u.account.totalCallCost = 0;
                        u.account.totalMessageCost = 0;
                        u.account.totalDataUsageCost = 0;
                        u.account.totalMessages = 0;
                        u.account.totalCallMinutes = 0;
                        u.account.totalDataUsageKBS = 0;

                        strcpy(u.account.tariffplan.name, "");
                        u.account.tariffplan.smsCost = 0;
                        u.account.tariffplan.callCostPerMinute = 0;
                        u.account.tariffplan.dataCostPerKiloByte = 0;
                        u.account.tariffplan.smsLimit = 0;
                        u.account.tariffplan.callMinutesLimit = 0;
                        u.account.tariffplan.dataUsageLimit = 0;
                        u.account.tariffplan.tariffTotalPrice = 0;

                        registerUser(u);
                        char ** offer = read_offers();
                        changeTariff(u.phoneNumber, strtok(offer[selection], "\t"));
                        bzero(buffer, 2000);

                    }
                i = strncmp("2", buffer, 1);
                if (i == 0){//Aggiungi tariffa
                        struct TariffPlan t;
                        strcpy(buffer, "Inserire Nome Tariffa: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        strcpy(t.name, buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Costo SMS: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        t.smsCost = atof(buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Costo Chiamate per Minuto: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        t.callCostPerMinute = atof(buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Costo Connessione Dati per KB: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        t.dataCostPerKiloByte = atof(buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Limite SMS: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        t.smsLimit = atof(buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Limite Minuti Chiamata: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        t.callMinutesLimit = atof(buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Limite KB Connessione Dati: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        t.dataUsageLimit = atof(buffer);
                        bzero(buffer, 2000);

                        strcpy(buffer, "Inserire Costo Totale Tariffa: ");
                        n = write(newsockfd, buffer, strlen(buffer));
                        if (n < 0){
                            error("Error on Writing.\n\n");
                        }
                        bzero(buffer, 2000);

                        n = read(newsockfd, buffer, 2000);
                        if (n < 0){
                            error("Error on reading.\n\n");
                        }
                        t.tariffTotalPrice = atof(buffer);
                        bzero(buffer, 2000);

                        createTariff(t);
                    }
                i = strncmp("3", buffer, 1);
                if (i == 0){//Visualizza statistiche utenti
                    bzero(buffer, 2000);
                    const char *filename = "Subscribers.json";
                    char *users = read_file(filename);
                    cJSON *root = cJSON_Parse(users);
                    cJSON *element;
                    cJSON_ArrayForEach(element, root){
                        cJSON *account = cJSON_GetObjectItem(element, "account");
                        cJSON *tariffPlan = cJSON_GetObjectItem(account, "tariffPlan");
                        double totalSMS = cJSON_GetObjectItem(account, "totalMessages")->valuedouble;
                        double smsLimit = cJSON_GetObjectItem(tariffPlan, "smsLimit")->valuedouble;
                        float smsUsage = ((float)totalSMS / (float)smsLimit) * 100;
                        double totalMinutes = cJSON_GetObjectItem(account, "totalCallsMinutes")->valuedouble;
                        double minuteLimit = cJSON_GetObjectItem(tariffPlan, "callMinutesLimit")->valuedouble;
                        float minuteUsage = ((float)totalMinutes / (float)minuteLimit) * 100;
                        double totalKB = cJSON_GetObjectItem(account, "totalDataUsageKBS")->valuedouble;
                        double kbLimit = cJSON_GetObjectItem(tariffPlan, "dataUsageLimit")->valuedouble;
                        float kbUsage = ((float)totalKB / (float)kbLimit) * 100;
                        char *name = cJSON_GetObjectItem(element, "name")->valuestring;
                        float balance = (float)cJSON_GetObjectItem(account, "balance")->valuedouble;
                        // Ottenimento valori utilizzo di ciascun utente
                        char row[100]; 
                        sprintf(row, "%s:\n\t%.2f\t%.2f\t%.2f\t%.2f", name, smsUsage, minuteUsage, kbUsage, balance);
                        strcat(buffer, row);
                        strcat(buffer, "\n");
                        //Concatenazione delle stringhe per ottenere tutti gli utenti in una sola stringa
                    }
                    n = write(newsockfd, buffer, strlen(buffer));
                    if (n < 0){
                        error("Error on Writing.\n\n");
                    }
                    bzero(buffer, 2000);
                    //Invio della stringa
                }
            }
        }
    }
    //Chiusura connessione
    close(newsockfd);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]){
    sem_init(&semaphore, 0, 1);
    if (argc < 2){
        fprintf(stderr, "Port number not provided.\n\n");
        exit(1);
    }

    int sockfd , newsockfd, portno;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t clilen;
    pthread_t thread_id;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0){
        error("Error opening socket.\n\n");
    }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    portno = atoi(argv[1]);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
        error("Binding Failed.\n\n");
    }

    listen(sockfd, 5);
    clilen = sizeof(cli_addr);
    //Inizializzazione del socket

    while (1) {
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        if (newsockfd < 0){
            error("Error on Accept.\n\n");
        }

        if (pthread_create(&thread_id, NULL, handle_connection, (void*)&newsockfd) < 0){
            error("Could not create thread.\n\n");
        }
        //Accettazione della connessione e creazione di un nuovo thread per gestirlo
    }

    close(sockfd);
    return 0;
}
