#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

/**
 * @file error_handler.c
 * @brief Questo file contiene la definizione della funzione di gestione degli errori.
 */

/**
 * @brief Stampa un messaggio di errore e termina il programma.
 *
 * Questa funzione utilizza `perror` per stampare il messaggio di errore passato come argomento
 * e poi termina il programma con un codice di uscita 1.
 *
 * @param msg Il messaggio di errore da stampare.
 *
 * @note La funzione non ritorna, poich� il programma viene terminato tramite `exit`.
 */

void error(const char *msg){
    perror(msg);
    exit(1);
}

/**
 * @file string_divider.c
 * @brief Questo file contiene la definizione della funzione di divisione delle stringhe.
 */

/**
 * @brief Divide una stringa in sottostringhe basate sul carattere spazio.
 *
 * Questa funzione prende una stringa e la divide in sottostringhe ogni volta che trova uno spazio.
 * Il numero di sottostringhe trovate viene memorizzato nel parametro `num_sottostringhe`.
 *
 * @param stringa La stringa da dividere.
 * @param num_sottostringhe Puntatore a un intero dove verr� memorizzato il numero di sottostringhe trovate.
 * @return Un array di puntatori a caratteri, ciascuno puntante a una sottostringa.
 *
 * @note La memoria per le sottostringhe � allocata dinamicamente e deve essere liberata dal chiamante.
 */
char** divide_stringa(const char* stringa, int* num_sottostringhe) {
    // Conta il numero di sottostringhe
    int count = 0;
    for (int i = 0; stringa[i]; i++) {
        if (stringa[i] == ' ') {
            count++;
        }
    }

 /**
* @brief Incrementa il conteggio per l'ultima sottostringa.
*
* Dopo aver contato tutti gli spazi nella stringa, si incrementa il conteggio
* per considerare l'ultima sottostringa che si trova dopo l'ultimo spazio.
*/
    // Incrementa il conteggio per l'ultima sottostringa
    count++;

/**
     * @brief Alloca memoria per i puntatori alle sottostringhe.
     *
     * Utilizza la funzione `malloc` per allocare memoria sufficiente a contenere `count`
     * puntatori a caratteri, che verranno utilizzati per memorizzare le sottostringhe.
     */
    // Alloca memoria per l'array di puntatori a char
    char** sottostringhe = (char**)malloc(count * sizeof(char*));

/**
     * @brief Controlla se l'allocazione della memoria � riuscita.
     *
     * Verifica che la chiamata a `malloc` non abbia restituito NULL, il che indicherebbe
     * un errore di allocazione della memoria. In tal caso, stampa un messaggio di errore
     * e termina il programma.
     */
    // Controllo sull'allocazione di memoria
    if (sottostringhe == NULL) {
        printf("Errore: Impossibile allocare memoria\n");
        exit(1);
    }

    // Inizializza il numero di sottostringhe
    *num_sottostringhe = count;

/**
     * @brief Tokenizza la stringa e copia le sottostringhe allocate.
     *
     * Utilizza `strtok` per suddividere la stringa in sottostringhe basate sul carattere spazio.
     * Ogni sottostringa viene allocata dinamicamente e copiata nell'array `sottostringhe`.
     */
    // Copia le sottostringhe nell'array
    char* token = strtok((char*)stringa, " ");
    int index = 0;
    while (token != NULL) {
    	/**
         * @brief Alloca memoria per una singola sottostringa e la copia nell'array.
         *
         * Utilizza `malloc` per allocare memoria sufficiente a contenere la sottostringa e `strcpy`
         * per copiare il contenuto della sottostringa nell'array.
         *
         * @param token Puntatore alla sottostringa corrente.
         */
        sottostringhe[index] = (char*)malloc(strlen(token) + 1);
        strcpy(sottostringhe[index], token);
        index++;
        token = strtok(NULL, " ");
    }

    return sottostringhe;
}

int main(int argc, char *argv[]){
    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    char buffer[2000];
    if (argc < 3){
        fprintf(stderr, "usage %s hostname port\n", argv[0]);
    }
    
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);


    if (sockfd < 0){
        error("Error opening socket.\n\n");
    }
    //Inizializzazione del socket
    server = gethostbyname(argv[1]);
    if (server == NULL)
        fprintf(stderr, "Error, no such host.\n\n");
        bzero((char *) &serv_addr, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;
        bcopy((char *) server->h_addr, (char *) &serv_addr.sin_addr.s_addr, server->h_length);
        serv_addr.sin_port = htons(portno);
        if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
            error("Connection failed");
        }
        //Gestione della connessione
        while(1){
            //Lettura
            bzero(buffer, 2000);
            n = read(sockfd, buffer, 2000);
            if (n < 0){
                error("Error on reading\n");
            }
            printf("Server:\n%s\n", buffer);

            int i = strncmp("0", buffer, 1);
            if (i == 0) break;

            if (strstr(buffer, "contact") != NULL){// LOGICA CHIAMATA
                int sockfd1, portno1, n1;
                struct sockaddr_in serv_addr1;
                struct hostent *server1;

                char buffer1[2000];
                int n_;
                char **dati = divide_stringa(buffer, &n_);
                portno1 = 9895;//atoi(dati[2]);
                sockfd1 = socket(AF_INET, SOCK_STREAM, 0);

                if (sockfd < 0){
                    error("Error opening socket.\n\n");
                }
                server1 = gethostbyname(dati[1]);
                bzero((char *) &serv_addr1, sizeof(serv_addr1));
                serv_addr1.sin_family = AF_INET;
                bcopy((char *) server1->h_addr, (char *) &serv_addr1.sin_addr.s_addr, server1->h_length);
                serv_addr1.sin_port = htons(portno1);
                if (connect(sockfd1, (struct sockaddr *) &serv_addr1, sizeof(serv_addr1)) < 0){
                    error("Connection failed");
                }
                while(1){
                    bzero(buffer1, 2000);
                    n = read(sockfd, buffer1, 2000);
                    if (n < 0){
                        error("Error on writing\n");
                    }
                    printf("%s", buffer1);
                    bzero(buffer1, 2000);
                }
            }

            //Scrittura
            bzero(buffer, 2000);
            fgets(buffer, 2000, stdin);
            n = write(sockfd, buffer, strlen(buffer));
            if (n < 0){
                error("Error on writing\n");
            }
        }
    close(sockfd);
    return 0;
}
