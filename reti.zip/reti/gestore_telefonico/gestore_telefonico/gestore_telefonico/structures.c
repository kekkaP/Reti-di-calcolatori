#include <stdbool.h>

struct TariffPlan{
    char name[2000];
    float smsCost;
    float callCostPerMinute;
    float dataCostPerKiloByte;
    float smsLimit;
    float callMinutesLimit;
    float dataUsageLimit;
    float tariffTotalPrice;
};

struct Account{
    struct TariffPlan tariffplan;
    float balance;
    float totalCallCost;
    float totalMessageCost;
    float totalDataUsageCost;
    float totalMessages;
    float totalCallMinutes;
    float totalDataUsageKBS;
};

struct User{
    char name[2000];
    char surname[2000];
    char residence[2000];
    char phoneNumber[2000];
    struct Account account;
};

struct Contatto {
    struct sockaddr_in indirizzoIP;
    int port;
    char numeroTelefono[2000];
    int occupato;
    char messaggi[50][2000];
};
struct Contatto clientList[5];

void aggiungiClient(struct Contatto nuovoContatto) {
    bool listaPiena = false; // Inizializza su false

    // Scorrere la lista per verificare se c'è almeno uno spazio libero
    for (int i = 0; i < 5; i++) {
        if (clientList[i].occupato == 0) {
            clientList[i].indirizzoIP = nuovoContatto.indirizzoIP;
            strcpy(clientList[i].numeroTelefono, nuovoContatto.numeroTelefono);
            clientList[i].occupato = nuovoContatto.occupato;
            clientList[i].port = nuovoContatto.port;
            for (int j = 0; j < 10; j++) {
                strcpy(clientList[i].messaggi[j], nuovoContatto.messaggi[j]);
            }
            printf("Contatto aggiunto alla lista.\n");
            return; // Esci subito dopo aver aggiunto il contatto
        }
    }

    // Se il ciclo è finito senza trovare uno spazio libero, la lista è piena
    printf("La lista dei contatti è piena, impossibile aggiungere il contatto.\n");
}


#include <netinet/in.h> // Per struct in_addr

void eliminaClientERiordina(struct in_addr indirizzoIPEliminare) {
    int posizione = -1;
    for (int i = 0; i < 5; i++) {
        if (memcmp(&clientList[i].indirizzoIP.sin_addr, &indirizzoIPEliminare, sizeof(struct in_addr)) == 0) {
            posizione = i;
            break;
        }
    }

    if (posizione != -1) {
        // Elimina il client dalla lista e riordina
        for (int i = posizione; i < 5 - 1; i++) {
            clientList[i] = clientList[i + 1];
        }
        printf("Client eliminato dalla lista e lista riordinata.\n");
    } else {
        printf("Client non trovato nella lista.\n");
    }
}

char* getTelefonoDaIP(struct in_addr ipAddress) {
    for (int i = 0; i < 5; ++i) {
        if (memcmp(&(clientList[i].indirizzoIP.sin_addr), &ipAddress, sizeof(struct in_addr)) == 0) {
            return clientList[i].numeroTelefono;
        }
    }
    return NULL; // Se l'indirizzo IP non è presente nella lista
}

struct in_addr getIpDaTelefono(char *number){
    for (int i = 0; i < 5; ++i){
        if (strcmp(clientList[i].numeroTelefono, number) == 0){
            return clientList[i].indirizzoIP.sin_addr;
        }
    }
}

int getPortaDaTelefono(char *number){
    for (int i = 0; i < 5; ++i){
        if (strcmp(clientList[i].numeroTelefono, number) == 0){
            return clientList[i].port;
        }
    }
    return 0;
}


char *addMessage(char *number, char *message) {
    // Cerca il contatto con il numero di telefono fornito
    int i;
    for (i = 0; i < 5; i++) {
        if (strcmp(clientList[i].numeroTelefono, number) == 0) {
            // Trovato il contatto, cerca un posto libero per il messaggio
            int j;
            for (j = 0; j < 10; j++) {
                if (clientList[i].messaggi[j][0] == '\0') {
                    // Trovato spazio libero, aggiungi il messaggio
                    strcpy(clientList[i].messaggi[j], message);
                    return "Messaggio aggiunto con successo.";
                }
            }
            // Non c'è spazio libero per aggiungere il messaggio
            return "Limite di messaggi per questo contatto raggiunto.";
        }
    }
    // Numero di telefono non trovato nella lista dei contatti
    return "Numero di telefono non trovato.";
}

void addPort(struct in_addr ip, int port){
    char *number = getTelefonoDaIP(ip);
    if (number != NULL) {
        for (int i = 0; i < 5; i++) {
            if (strcmp(clientList[i].numeroTelefono, number) == 0) {
                clientList[i].port = port;
                printf("Porta aggiunta correttamente\n");
                break; // Possiamo interrompere il ciclo dopo aver trovato il numero di telefono
            }
        }
    } else {
        printf("Nessun numero di telefono trovato per l'IP specificato.\n");
    }
}

bool numberExists(char *number){
    if (number != NULL){
        for (int i = 0; i < 5; i++){
            if (strcmp(clientList[i].numeroTelefono, number) == 0){
                return true;
                break;
            }
        }
        return false;
    }
}



char *getMessages(char *number) {
    static char messages[10 * 2000];

    // Cerca il contatto con il numero di telefono fornito
    int i;
    for (i = 0; i < 5; i++) {
        if (strcmp(clientList[i].numeroTelefono, number) == 0) {
            // Trovato il contatto, concatena i messaggi
            strcpy(messages, "");
            int j;
            for (j = 0; j < 10; j++) {
                if (clientList[i].messaggi[j][0] != '\0') {
                    strcat(messages, clientList[i].messaggi[j]);
                    strcat(messages, "\n"); // Aggiungi un newline tra i messaggi
                    strcpy(clientList[i].messaggi[j], "");
                }
            }
            return messages;
        }
    }
    // Numero di telefono non trovato nella lista dei contatti
    return "Numero di telefono non trovato.";
}