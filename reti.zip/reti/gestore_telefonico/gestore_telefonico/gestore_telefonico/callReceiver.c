#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>


void error(const char *msg){
    perror(msg);
    exit(1);
}

void *handle_connection(void *socket_desc) {
    int newsockfd = *((int*)socket_desc);
    char buffer[2000];
    int n;

    struct sockaddr_in cli_addr;
    socklen_t cli_len = sizeof(cli_addr);
    char ipString[2000];

    while(1){
        bzero(buffer, 2000);
        strcpy(buffer, "Ricevuta");
        n = write(newsockfd, buffer, strlen(buffer));
        if (n < 0){
            error("Error on write");
        }
        bzero(buffer, 2000);
        
        n = read(newsockfd, buffer, 2000);
        if(n < 0){
            error("Error on reading\n");
        }
        printf("%s\n", buffer);

        
    }

    if (getpeername(newsockfd, (struct sockaddr*)&cli_addr, &cli_len) == 0) {
        printf("Chiamata in arrivo da: %s\n", buffer);
    }

    close(newsockfd);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]){
    if (argc < 2){
        fprintf(stderr, "Port number not provided.\n\n");
        exit(1);
    }

    int sockfd , newsockfd, portno;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t clilen;
    pthread_t thread_id;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0){
        error("Error opening socket.\n\n");
    }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    portno = atoi(argv[1]);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
        error("Binding Failed.\n\n");
    }

    listen(sockfd, 5);
    clilen = sizeof(cli_addr);

    while (1) {
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        if (newsockfd < 0){
            error("Error on Accept.\n\n");
        }

        if (pthread_create(&thread_id, NULL, handle_connection, (void*)&newsockfd) < 0){
            error("Could not create thread.\n\n");
        }
    }
}